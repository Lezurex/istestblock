window.addEventListener("mousemove", event => event.stopImmediatePropagation(), true);
window.addEventListener("keyup", event => event.stopImmediatePropagation(), true);
window.addEventListener("keydown", event => event.stopImmediatePropagation(), true);